-- Create the Profiles table
CREATE TABLE Profiles (
    Id INT PRIMARY KEY,
    Name NVARCHAR(100),
    Username NVARCHAR(50),
    Product NVARCHAR(100)
);

-- Insert data into the Profiles table
INSERT INTO Profiles (Id, Name, Username, Product) VALUES
(1, 'Alice Johnson', 'alicej@gmail.com', 'Solar Panel Installation'),
(2, 'Bob Smith', 'bobsmith@gmail.com', 'Wind Turbine Maintenance'),
(3, 'Carol White', 'carolw@gmail.com', 'Biofuel Production'),
(4, 'David Brown', 'davidb@gmail.com', 'Electric Vehicle Charging Station'),
(5, 'Eva Green', 'evagreen@gmail.com', 'Smart Home Energy Management');

-- Create the Products table
CREATE TABLE Products (
    Id INT PRIMARY KEY,
    Name NVARCHAR(100),
    Category NVARCHAR(50),
    ProductionDate DATE
);

-- Insert data into the Products table
INSERT INTO Products (Id, Name, Category, ProductionDate) VALUES
(1, 'Solar Panel', 'Renewable Energy', '2023-01-15'),
(2, 'Wind Turbine', 'Renewable Energy', '2023-02-20'),
(3, 'Biofuel Generator', 'Alternative Energy', '2023-03-10'),
(4, 'EV Charging Station', 'Infrastructure', '2023-04-05'),
(5, 'Smart Home Energy System', 'Home Automation', '2023-05-22');
